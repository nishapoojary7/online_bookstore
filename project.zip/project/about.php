<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<div class="heading">
   <h3>about us</h3>
   <p> <a href="home.php">home</a> / about </p>
</div>

<section class="about">

   <div class="flex">

      <div class="image">
         <img src="img1.jpg" alt="">
      </div>

      <div class="content">
         <h3>why choose us?</h3>
         <p>At DivyaDegulam.... is the Temple Management Package is a highly scalable product for Hindu Temples. It offers a complete automation in billing and accounts, inventory, staff management and administration sections. It helps temple administrators to assure effective devotee service.

Temple Management solution is bundled with an excellent accounting package which enables easy operation and efficient reporting. It's available with internet support to allow devotees to make online offerings, pooja bookings, and many more useful features.</p>
         <a href="contact.php" class="btn">contact us</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">client's reviews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/pic-1.png" alt="">
         <p> "I love how easy it is to navigate through the temple's website. Finding information about upcoming events and services is a breeze! </p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Jayadev</h3>
      </div>

      <div class="box">
         <img src="images/pic-2.png" alt="">
         <p>"The temple website provides thorough information about its history, spiritual teachings, and community activities. I appreciate the depth of content and how well it's presented."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Lalitha sharma</h3>
      </div>

      <div class="box">
         <img src="images/pic-3.png" alt="">
         <p>"The website's design is stunning! The serene images and calming color scheme perfectly reflect the temple's spiritual atmosphere." </p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Virat</h3>
      </div>

      <div class="box">
         <img src="images/pic-4.png" alt="">
         <p>"I often check the temple's website on my phone, and I'm impressed by how well it adapts to smaller screens. It's so convenient to access important information on the go."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Soumya patil</h3>
      </div>

      <div class="box">
         <img src="images/pic-5.png" alt="">
         <p>"I love how the website fosters community engagement with its interactive features. The event calendar keeps me updated on all the happenings, and the forum is a great space for discussions."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Akshay kumar</h3>
      </div>

      <div class="box">
         <img src="images/pic-6.png" alt="">
         <p>"As someone with visual impairments, I appreciate the efforts the temple has made to ensure accessibility. The website is easy to navigate with screen readers, and the alt text for images is very helpful."</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Anushka</h3>
      </div>

   </div>

</section>

<?php include 'footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>